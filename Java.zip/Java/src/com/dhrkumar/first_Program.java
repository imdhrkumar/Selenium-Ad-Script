package com.dhrkumar;

import com.dhrkumar.LearnJava.ChildClass;

public class first_Program extends ChildClass{

    public static void main(String[] args) {

        String [] name = { "Java", "C++", "Java", "PHP", "C++", "Java", "PHP"};
        for(int i =0; i<name.length; i++){
            for(int j=i+1; j<name.length;j++){
                if(name[i]==name[j]){
                    System.out.println("duplicate "+name[j]);

                }

            }

        }

    }
}

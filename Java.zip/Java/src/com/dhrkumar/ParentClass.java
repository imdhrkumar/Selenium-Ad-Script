package com.dhrkumar;

public class ParentClass {

    public int a = 10, b=20;
    public int sum(){
        int res = a+b;
        return res;
    }

    public static void main(String[] args) {
	// write your code here
    }
}

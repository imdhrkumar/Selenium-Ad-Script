package com.dhrkumar.selenium;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Practice_Session1 {

    public static void main(String[] args) throws InterruptedException {

        System.setProperty("webdriver.chrome.driver", "/Users/dhruv-kumar/Documents/Selenium/chromedriver");

        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        Thread.sleep(2000);

        driver.get("https://mail.rediff.com/cgi-bin/login.cgi");
        Thread.sleep(2000);

        WebElement loginClick = driver.findElement(By.name("proceed"));
        loginClick.click();
        Thread.sleep(2000);

        String error = "Please enter a valid user name";
        Alert popupscreen = driver.switchTo().alert();
        String popuperrormessage = popupscreen.getText();
        System.out.println(popuperrormessage);

        if(popuperrormessage.equalsIgnoreCase(error))
        {
            System.out.println("Error PopUp Message is appearing Correctly, Hence It is Pass");
        }
        else {
            System.out.println("Not Matched--Failed");
        }

        Thread.sleep(2000);

        popupscreen.accept();
        Thread.sleep(2000);

        WebElement userName = driver.findElement(By.id("login1"));

        boolean checkDisplayStatus = userName.isDisplayed();
        System.out.println(checkDisplayStatus);
        if(checkDisplayStatus=true){
            System.out.println("Test Case is Successfully Pass");
        }
        else
        {
            System.out.println("Not True--Then its failed");
        }

        boolean checkEnabledStatus = userName.isEnabled();
        System.out.println(checkEnabledStatus);
        if(checkEnabledStatus=true){
            System.out.println("Test Case is Successfully Pass");
        }
        else{
            System.out.println("Not True--Then its failed");
        }

        Thread.sleep(2000);

        userName.sendKeys("imlovelypathak");
        String getAttributeValue = userName.getAttribute("id");
        System.out.println(getAttributeValue);
        Thread.sleep(2000);

        //driver.findElement(By.xpath("//body/div[@id=‘google_center_div’]/div[@id=‘google_image_div’]/a[@id=‘aw0’]/amp-img[1]/img[1]")).click();
        driver.close();
    }
}

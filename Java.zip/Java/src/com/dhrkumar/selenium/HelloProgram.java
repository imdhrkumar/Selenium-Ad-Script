package com.dhrkumar.selenium;


import io.netty.util.Timeout;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import java.util.List;
import java.util.concurrent.TimeUnit;

public class HelloProgram {

    public static void main(String[] args) throws InterruptedException {

        //Instantiate the Google Chrome Driver
        System.setProperty("webdriver.chrome.driver", "/Users/dhruv-kumar/Documents/Selenium/chromedriver");

        //Create Chrome Browser Driver
        //WebDriver and ChromeDriver() -> Library
        //Creating chrome driver in web driver
        WebDriver driver = new ChromeDriver(); // launching the blank browser

        //Maximize the size of windows
        driver.manage().window().maximize();
        driver.manage().deleteAllCookies();

        //Launch the Fleetx browser
        driver.get("https://staging.fleetx.io/");

        //Find the Sign in link
        driver.findElement(By.linkText("Sign in →")).click();

        //Enter the UserName
       WebElement username = driver.findElement(By.name("email"));
       username.sendKeys("dhruv.kumar@fleetx.io");

        //Enter the Password
        driver.findElement(By.name("password")).sendKeys("Lucky95@");

        //Click on login Button
        driver.findElement(By.cssSelector("button.space-bottom-2")).click();

        //thread sleep
        Thread.sleep(4000);

        //Capture the current URL
        String currentURL =  driver.getCurrentUrl();
        System.out.println(currentURL);

        //Validation
        if(currentURL.equals("https://staging.fleetx.io/dashboard/realtime/overview")){
            System.out.println("URL has been perfectly matched with the current URL");
        }
        else{
            System.out.println("Not Matched: Failed");
        }

        // Drop-down open using WebElement
//        WebElement wb = driver.findElement(By.cssSelector("span.header-text:nth-child(1)"));
//        wb.click();

        //List gets open then select Switch Account
//        wb = driver.findElement(By.cssSelector("div.custom-list-wrapper:nth-child(2) > div:nth-child(1)"));
//        wb.click();
//
//        Thread.sleep(400);
//        driver.switchTo().wait();
//
//        //Select the account id from the frame
//        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//
//        WebElement modalTitle = driver.findElement(By.xpath("//div[@class='modal-header']/h5"));
//        System.out.println("Modal Text: "+modalTitle.getText());

        WebElement textDropdown = driver.findElement(By.cssSelector("span.header-text:nth-child(1)"));
        textDropdown.click();
        List <WebElement> lists = driver.findElements(By.xpath("//div[contains(@class,'custom-list-wrapper single-column right')]/div"));
        for (WebElement list: lists)
        {
            System.out.println(list.getText());
            if(list.getText().equals("Switch Account")){
                System.out.println("Matched: "+list.getText());
                list.click();
                break;
            }
        }
        driver.switchTo().wait();
//        String text = driver.findElement(By.className("modal-title")).getText();
//        System.out.println(text);
        WebElement popuphandle = driver.findElement(By.xpath("//*[@class=' css-2b097c-container']"));
        popuphandle.click();






        //Closed the browser window
        driver.close();



    }


    }


package com.dhrkumar;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

class abc  {

    public static void main(String[] args) throws InterruptedException {

        System.setProperty("webdriver.chrome.driver", "/Users/dhruv-kumar/Documents/Selenium/chromedriver");
        WebDriver driver = new ChromeDriver();
        driver.get("https://staging.fleetx.io/");
        driver.manage().window().maximize();
        String getTitle = driver.getTitle();
        System.out.println("Get Title of the WebPage: " +getTitle);
        String currentURL = driver.getCurrentUrl();
        if(currentURL.equals("https://staging.fleetx.io/")){
            System.out.println("Valid URL");
        }
        else{
            System.out.println("Not Valid one");
        }
        System.out.println("Get currentURL of the Webpage: " +currentURL);
        //driver.wait(5);
        driver.quit();

    }

}





package com.dhrkumar.LearnJava;

import com.dhrkumar.ParentClass;

public class ChildClass extends ParentClass {

    public static void main(String[] args) {

        ChildClass obj = new ChildClass();
        int result = obj.sum();
        System.out.println(result);//30
        System.out.println(obj.b);//20

    }
}
